package view;

public class ImpressaoIngressoView {
    public static void exibir() {}
}

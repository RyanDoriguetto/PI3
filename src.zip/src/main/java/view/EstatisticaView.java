package view;

public class EstatisticaView {
    public static void exibir() {}
}

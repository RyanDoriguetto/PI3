package view;

import javax.swing.*;
import java.awt.*;

public class CompraIngressoView extends JFrame {
    private JPanel painelPrincipal;
    private JPanel painelUsuario;
    private JPanel painelPeca;
    private JPanel painelHorario;
    private JPanel painelSessao;
    private JPanel painelAssentos;
    private JButton botaoConfirmarSelecao;
    private JButton botaoConcluirCompra;
    private JRadioButton[] botoesPeca;
    private JRadioButton[] botoesHorario;
    private JRadioButton[] botoesSessao;
    private ButtonGroup grupoPeca;
    private ButtonGroup grupoHorario;
    private ButtonGroup grupoSessao;
    private JTextArea areaUsuario;

    public static void exibir() {
        setTitle("Compra de Ingressos");
        setSize(1050, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        ImageIcon icone = new ImageIcon("iconeTeatro.png");
        Image imagemIcone = icone.getImage().getScaledInstance(64, 64, Image.SCALE_SMOOTH);
        setIconImage(imagemIcone);

        painelPrincipal = new JPanel();
        painelPrincipal.setLayout(new BoxLayout(painelPrincipal, BoxLayout.Y_AXIS));

        painelUsuario = new JPanel(new FlowLayout(FlowLayout.CENTER));
        areaUsuario = new JTextArea();
        areaUsuario.setEditable(false);
        areaUsuario.setOpaque(false);
        areaUsuario.setFocusable(false);
        areaUsuario.setFont(new JLabel().getFont());
        painelUsuario.add(areaUsuario);
        painelPrincipal.add(painelUsuario);

        painelPeca = new JPanel(new FlowLayout(FlowLayout.LEFT));
        painelPeca.add(new JLabel("Selecione a peça desejada:  "));
        String[] nomePecas = {"Lago dos Cisnes", "Chapeuzinho Vermelho", "Moby-Dick"};
        botoesPeca = new JRadioButton[nomePecas.length];
        grupoPeca = new ButtonGroup();
        for (int i = 0; i < nomePecas.length; i++) {
            botoesPeca[i] = new JRadioButton(nomePecas[i]);
            grupoPeca.add(botoesPeca[i]);
            painelPeca.add(botoesPeca[i]);
        }
        painelPrincipal.add(painelPeca);

        painelHorario = new JPanel(new FlowLayout(FlowLayout.LEFT));
        painelHorario.add(new JLabel("Selecione o horário de preferência:"));
        String[] nomeHorario = {"Manhã", "Tarde", "Noite"};
        botoesHorario = new JRadioButton[nomeHorario.length];
        grupoHorario = new ButtonGroup();
        for (int i = 0; i < nomeHorario.length; i++) {
            botoesHorario[i] = new JRadioButton(nomeHorario[i]);
            grupoHorario.add(botoesHorario[i]);
            painelHorario.add(botoesHorario[i]);
        }
        painelPrincipal.add(painelHorario);

        painelSessao = new JPanel(new FlowLayout(FlowLayout.LEFT));
        painelSessao.add(new JLabel("Selecione a sessão de preferência: "));
        String[] nomeSessao = {"Plateia A R$ 40,00", "Plateia B R$ 60,00", "Camarotes R$ 80,00", "Frisas R$ 120,00", "Balcão Nobre R$ 250,00"};
        botoesSessao = new JRadioButton[nomeSessao.length];
        grupoSessao = new ButtonGroup();
        for (int i = 0; i < nomeSessao.length; i++) {
            botoesSessao[i] = new JRadioButton(nomeSessao[i]);
            grupoSessao.add(botoesSessao[i]);
            painelSessao.add(botoesSessao[i]);
        }
        painelPrincipal.add(painelSessao);

        botaoConfirmarSelecao = new JButton("Confirmar seleção");
        botaoConfirmarSelecao.setAlignmentX(Component.CENTER_ALIGNMENT);
        painelPrincipal.add(botaoConfirmarSelecao);

        painelAssentos = new JPanel(new BorderLayout());
        painelPrincipal.add(painelAssentos);

        add(painelPrincipal);
        setVisible(true);
    }

    public void setUsuarioTexto(String texto) {
        areaUsuario.setText(texto);
    }

    public JPanel getPainelAssentos() {
        return painelAssentos;
    }

    public JButton getBotaoConfirmarSelecao() {
        return botaoConfirmarSelecao;
    }

    public ButtonGroup getGrupoPeca() {
        return grupoPeca;
    }

    public ButtonGroup getGrupoHorario() {
        return grupoHorario;
    }

    public ButtonGroup getGrupoSessao() {
        return grupoSessao;
    }

    public JRadioButton[] getBotoesPeca() {
        return botoesPeca;
    }

    public JRadioButton[] getBotoesHorario() {
        return botoesHorario;
    }

    public JRadioButton[] getBotoesSessao() {
        return botoesSessao;
    }
}
